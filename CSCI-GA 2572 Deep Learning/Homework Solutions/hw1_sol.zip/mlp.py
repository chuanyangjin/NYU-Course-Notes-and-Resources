import torch

class MLP:
    def __init__(
        self,
        linear_1_in_features,
        linear_1_out_features,
        f_function,
        linear_2_in_features,
        linear_2_out_features,
        g_function
    ):
        """
        Args:
            linear_1_in_features: the in features of first linear layer
            linear_1_out_features: the out features of first linear layer
            linear_2_in_features: the in features of second linear layer
            linear_2_out_features: the out features of second linear layer
            f_function: string for the f function: relu | sigmoid | identity
            g_function: string for the g function: relu | sigmoid | identity
        """
        self.f_function = f_function
        self.g_function = g_function

        self.parameters = dict(
            W1 = torch.randn(linear_1_out_features, linear_1_in_features),
            b1 = torch.randn(linear_1_out_features),
            W2 = torch.randn(linear_2_out_features, linear_2_in_features),
            b2 = torch.randn(linear_2_out_features),
        )
        self.grads = dict(
            dJdW1 = torch.zeros(linear_1_out_features, linear_1_in_features),
            dJdb1 = torch.zeros(linear_1_out_features),
            dJdW2 = torch.zeros(linear_2_out_features, linear_2_in_features),
            dJdb2 = torch.zeros(linear_2_out_features),
        )

        # put all the cache value you need in self.cache
        self.cache = dict()

    def forward(self, x):
        """
        Args:
            x: tensor shape (batch_size, linear_1_in_features)
        """
        # TODO: Implement the forward function
        self.x = x
        
        self.h1 = torch.matmul(x, self.parameters['W1'].t()) + self.parameters['b1']
        
        self.act1 = self.activation_fn(self.h1, self.f_function)
        
        self.out = torch.matmul(self.act1, self.parameters['W2'].t()) + self.parameters['b2']
        
        self.act2 = self.activation_fn(self.out, self.g_function)
        
        return self.act2
    
    def backward(self, dJdy_hat):
        """
        Args:
            dJdy_hat: The gradient tensor of shape (batch_size, linear_2_out_features)
        """
        # TODO: Implement the backward function
        batch_size = dJdy_hat.shape[0]
        
        dJdout = dJdy_hat*self.partial_derivative_act(self.out, self.g_function)
        dJdh1 = torch.matmul(dJdout, self.parameters['W2'])*self.partial_derivative_act(self.h1, self.f_function)
        
        self.grads['dJdW2'] = torch.matmul(dJdout.t(), self.act1)
        self.grads['dJdb2'] = torch.squeeze(torch.matmul(dJdout.t(), torch.ones((batch_size, 1))), dim=1)
        self.grads['dJdW1'] = torch.matmul(dJdh1.t(), self.x)
        self.grads['dJdb1'] = torch.squeeze(torch.matmul(dJdh1.t(), torch.ones((batch_size, 1))), dim=1)
    
    def activation_fn(self, x, function_str):
        if function_str=='relu':
            x = torch.where(x>0, x, torch.zeros(x.shape))
        elif function_str=='sigmoid':
            x = 1 / (1+torch.exp(-x))
        
        return x
    
    def partial_derivative_act(self, x, function_str):
        if function_str=="relu":
            return torch.where(x>0, torch.ones(x.shape), torch.zeros(x.shape))
        elif function_str=="sigmoid":
            i = (1 / (1+torch.exp(-x)))
            return i * (1-i)
        
        return torch.ones(x.shape)
    
    def clear_grad_and_cache(self):
        for grad in self.grads:
            self.grads[grad].zero_()
        self.cache = dict()

def mse_loss(y, y_hat):
    """
    Args:
        y: the label tensor (batch_size, linear_2_out_features)
        y_hat: the prediction tensor (batch_size, linear_2_out_features)

    Return:
        J: scalar of loss
        dJdy_hat: The gradient tensor of shape (batch_size, linear_2_out_features)
    """
    # TODO: Implement the mse loss
    loss = torch.mean((y - y_hat)**2)
    
    dJdy_hat = (-2 * (y - y_hat)) / (y_hat.shape[0] * y_hat.shape[1])
    
    return loss, dJdy_hat

def bce_loss(y, y_hat):
    """
    Args:
        y_hat: the prediction tensor
        y: the label tensor
        
    Return:
        loss: scalar of loss
        dJdy_hat: The gradient tensor of shape (batch_size, linear_2_out_features)
    """
    # TODO: Implement the bce loss
    loss = torch.mean(torch.where(y>0.5, - y * torch.log(y_hat), - y * torch.log(y_hat) - (1-y)*torch.log(1-y_hat)))
    
    dJdy_hat = torch.where(y>0.5, (-(y/y_hat)), (((1-y)/(1-y_hat)) - (y/y_hat)))/(y_hat.shape[0] * y_hat.shape[1])
    
    return loss, dJdy_hat
